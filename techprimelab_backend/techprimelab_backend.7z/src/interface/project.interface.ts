export interface IProject {
    category: string,
    department: string,
    division: string,
    enddate: string,
    location: string,
    priority: string,
    reason: string,
    startdate: string,
    status: string,
    theme: string,
    type: string,
}